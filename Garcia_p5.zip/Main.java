import java.util.*;

class Main{

    public static TaskApp TApp = new TaskApp();
    //public ContactApp CApp = new ContactApp();

    public static void main(String args[]){
      DuelMenu();
    }

    private static void DuelMenu(){
      System.out.println("Select Your Application\n-----------------------\n");
      System.out.println("1) task list\n2) contact list\n3) quit\n");
      int Choice;

      try{
        Scanner in = new Scanner(System.in);
        Choice = in.nextInt();
        switch(Choice)
        {
          case 1: TApp.menu(); break;
          case 2: break;
          case 3: System.out.println("Closing application"); break;
          default: System.out.println("Error please choose a correct option from 1-3"); DuelMenu(); break;
        }
      }catch(InputMismatchException e){
          System.out.println("Please enter a valid menu option.\n");
          DuelMenu();
        }


    }

}